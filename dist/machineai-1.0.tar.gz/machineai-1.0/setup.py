from distutils.core import setup

setup(name='machineai',
      version='1.0',
      description='Python Artificial intelligence',
      author='KUSHA B K',
      author_email='kusha.b.k@gmail.com'
     )